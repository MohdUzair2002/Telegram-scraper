Hello !!!!!, 

How its works?????

- you must install Python 3
- Install Atom or any text editor (Not necessary )
- Install telethon using cmd  command: pip3 install telethon\
-Get your Api and Hash id from www.my.telegram.org/auth
-add detials to scrapper.py and adder.py
-Run scrapper.py and scrap group members.
-Run adder.py and add scrapped members to your group


Basically it scrapes member from group where the logined id is admin and it creates a .csv file.
And the adder reads .csv file and add member to the target group.





  
 ___            ___          __                       ____________ 
|   \          /   |         | |                     |____    ____|
| |\ \        / /| |   ___   | |         ___              |  |     
| | \ \      / / | |  / __ \ | |_____   / __ \     _      |  |     
| |  \ \    / /  | | | |  | ||  __   | | |  | |   |_|     |  |     
| |   \ \  / /   | | | |__| || |__|  | | |__| |           |  |     
|_|    \_\/_/    |_|  \ ___/ |_______|  \____/            |__|     
                                                                   
